chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get({ enabled: false, interval: 4 }, (res) => {
    chrome.storage.sync.set(res);
  });
});
