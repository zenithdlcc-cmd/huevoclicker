const toggleBtn = document.getElementById('toggle');
const intervalInput = document.getElementById('interval');

let enabled = false;

function render() {
  toggleBtn.textContent = enabled ? 'ВКЛ' : 'ВЫКЛ';
  toggleBtn.classList.toggle('on', enabled);
}

chrome.storage.sync.get({ enabled: false, interval: 4 }, (res) => {
  enabled = res.enabled;
  intervalInput.value = res.interval;
  render();
});

toggleBtn.addEventListener('click', () => {
  enabled = !enabled;
  chrome.storage.sync.set({ enabled });
  render();
});

intervalInput.addEventListener('change', () => {
  const v = Math.max(1, parseInt(intervalInput.value, 10) || 4);
  intervalInput.value = v;
  chrome.storage.sync.set({ interval: v });
});

document.getElementById('open').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://huevo.lol/clicker' });
});
