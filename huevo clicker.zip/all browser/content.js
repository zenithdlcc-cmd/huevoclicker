(() => {
  if (window.__hueClickerLoaded) return;
  window.__hueClickerLoaded = true;

  const CAT_ID = 'ck-cat';

  let enabled = false;
  let interval = 4;
  let worker = null;

  function loadSettings() {
    return chrome.storage.sync.get({ enabled: false, interval: 4 }, (res) => {
      enabled = res.enabled;
      interval = Math.max(1, Number(res.interval) || 4);
      updatePanel();
      if (enabled) startClicking(); else stopClicking();
    });
  }

  function saveState() {
    chrome.storage.sync.set({ enabled, interval });
  }

  function startClicking() {
    stopClicking();
    const blob = new Blob([`
      let iv = ${interval};
      function loop() {
        postMessage(1);
        setTimeout(loop, iv);
      }
      onmessage = (e) => { iv = Math.max(1, e.data | 0); };
      loop();
    `], { type: 'application/javascript' });
    worker = new Worker(URL.createObjectURL(blob));
    worker.onmessage = doClick;
    updatePanel();
  }

  function stopClicking() {
    if (worker) {
      worker.terminate();
      worker = null;
    }
    updatePanel();
  }

  function setIntervalMs(ms) {
    interval = Math.max(1, ms | 0);
    if (worker) worker.postMessage(interval);
    saveState();
    updatePanel();
  }

  function doClick() {
    if (!enabled) return;
    const cat = document.getElementById(CAT_ID);
    if (!cat) return;
    const rect = cat.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0 };
    cat.dispatchEvent(new PointerEvent('pointerdown', opts));
    cat.dispatchEvent(new MouseEvent('mousedown', opts));
    cat.dispatchEvent(new PointerEvent('pointerup', opts));
    cat.dispatchEvent(new MouseEvent('mouseup', opts));
    cat.dispatchEvent(new MouseEvent('click', opts));
  }

  function toggle() {
    enabled = !enabled;
    saveState();
    if (enabled) startClicking(); else stopClicking();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    if (changes.interval) {
      interval = Math.max(1, Number(changes.interval.newValue) || 4);
      if (worker) worker.postMessage(interval);
      updatePanel();
    }
    if (changes.enabled) {
      const was = enabled;
      enabled = !!changes.enabled.newValue;
      if (enabled && !was) startClicking();
      if (!enabled && was) stopClicking();
    }
  });

  function buildPanel() {
    if (document.getElementById('hue-clicker-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'hue-clicker-panel';
    panel.innerHTML = `
      <div id="hue-clicker-head">
        <span>huEVO Clicker</span>
        <button id="hue-clicker-hide" title="Свернуть">—</button>
      </div>
      <div id="hue-clicker-body">
        <label class="hue-row">
          <span>Кликер</span>
          <button id="hue-clicker-toggle" class="hue-btn">ВЫКЛ</button>
        </label>
        <label class="hue-row">
          <span>Интервал (мс)</span>
          <input id="hue-clicker-interval" type="number" min="1" max="60000" step="1">
        </label>
        <a id="hue-clicker-group" href="https://huevo.lol/extensions" target="_blank" rel="noopener">Группа huEVO</a>
      </div>
    `;
    document.documentElement.appendChild(panel);

    panel.querySelector('#hue-clicker-toggle').addEventListener('click', toggle);
    panel.querySelector('#hue-clicker-hide').addEventListener('click', () => {
      panel.classList.toggle('collapsed');
    });
    const intervalInput = panel.querySelector('#hue-clicker-interval');
    intervalInput.addEventListener('change', () => {
      setIntervalMs(parseInt(intervalInput.value, 10) || 4);
    });

    let drag = null;
    panel.querySelector('#hue-clicker-head').addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      const rect = panel.getBoundingClientRect();
      drag = { dx: e.clientX - rect.left, dy: e.clientY - rect.top };
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!drag) return;
      panel.style.left = (e.clientX - drag.dx) + 'px';
      panel.style.top = (e.clientY - drag.dy) + 'px';
      panel.style.right = 'auto';
      panel.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { drag = null; });
  }

  function updatePanel() {
    const toggleBtn = document.getElementById('hue-clicker-toggle');
    const intervalInput = document.getElementById('hue-clicker-interval');
    if (!toggleBtn) return;
    toggleBtn.textContent = enabled ? 'ВКЛ' : 'ВЫКЛ';
    toggleBtn.classList.toggle('on', enabled);
    if (document.activeElement !== intervalInput) intervalInput.value = interval;
  }

  buildPanel();
  loadSettings();
})();
